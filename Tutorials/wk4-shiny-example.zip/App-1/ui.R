library(shiny)

# ui.R

shinyUI(fluidPage(
))